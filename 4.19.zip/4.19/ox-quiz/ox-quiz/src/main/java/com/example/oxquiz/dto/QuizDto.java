package com.example.oxquiz.dto;

import com.example.oxquiz.entity.QuizEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuizDto {
    private Long id;
    private String content;
    private boolean answer;
    private String name;

    public static QuizDto fromQuizEntity(QuizEntity quizEntity) {
        return new QuizDto(
                quizEntity.getId(),
                quizEntity.getContent(),
                quizEntity.isAnswer(),
                quizEntity.getName()
        );
    } // Entity -> Dto

    public static QuizEntity fromQuizDto(QuizDto quizDto) {
        return new QuizEntity(
                quizDto.getId(),
                quizDto.getContent(),
                quizDto.isAnswer(),
                quizDto.getName()
        );
    } // Dto -> Entity
}
