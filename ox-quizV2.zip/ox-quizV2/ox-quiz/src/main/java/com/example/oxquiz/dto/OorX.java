package com.example.oxquiz.dto;


import lombok.Getter;

@Getter
public enum OorX {
    True("O") , False("X");

    private final String description;

    OorX(String description) {
        this.description = description;
    }
}
