package com.example.thymeleafTest.vo;

import lombok.Data;

import java.util.List;

@Data //Lombok 전부다 설정해줌
public class FormDto {
    private String name;
    private boolean trueOrFalse;
    private List<String> hobbies;
}
