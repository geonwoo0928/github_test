package com.example.thymeleafTest.controller;

import com.example.thymeleafTest.vo.Link;
import org.apache.catalina.startup.Tomcat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class linkTestController {
    @GetMapping("main")
    public String main(){
        return "articles/main";
    }

    @GetMapping("articles/list")
    public String listAll(Model model){
        String title ="/articles/list";
        String message = "전체 게시글 읽기 성공";

        model.addAttribute("title", title);
        model.addAttribute("message", message);

        return "articles/list_all";
    }

    @GetMapping("articles/{id}")
    public String listOne(@PathVariable("id") int id, Model model){
        String title = "/articles/list_one";
        String message = id+"번 게시글 읽어오기 성공";

        model.addAttribute("title",title);
        model.addAttribute("message",message);
        return "articles/list_one";
    }

    @GetMapping("articles/new")
    public String new2 (@RequestParam("name") String name, @RequestParam("height") int height, @RequestParam("weight") int weight, Model model){
        String title = "/articles/new?name="+name + "&height="+height+"&weight="+weight;
        String message = name+"의 키는 "+height+", 몸무게는 "+weight;
        model.addAttribute("title", title);
        model.addAttribute("message", message);
        return "articles/new";
    }
    @GetMapping("articles/update")
    public String update(Model model){
        String title="/articles/update";
        String message="업데이트 성공 화면 출력";

        model.addAttribute("title",title);
        model.addAttribute("message",message);

        return "articles/update_ok";
    }

    @GetMapping("articles/member/{id}")
    public String memberSelect(Model model,
                               @PathVariable("id") int id,
                               @RequestParam("name") String name,
                               @RequestParam("addr") String addr){
        String title ="/articles/member/{"+id+"}";
        String message = name+"이 선택되었습니다.";
        String message2 = addr+"도 선택되었습니다";

        model.addAttribute("message2", message2);
        model.addAttribute("title", title);
        model.addAttribute("message", message);

        return "articles/member-list";
    }
//    @GetMapping("articles/{id}/update")
//    public String updateById(@PathVariable("id") int id, Model model){
//        String title = "/articles/update";
//        String message = ""
//    }
}

