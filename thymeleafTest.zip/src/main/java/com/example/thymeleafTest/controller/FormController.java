package com.example.thymeleafTest.controller;

import com.example.thymeleafTest.vo.FormDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@Slf4j
public class FormController {
    @GetMapping("/form")
    public String showForm(Model model) {
        model.addAttribute("dto", new FormDto());

        return "form-test/form";
    }

    @PostMapping("/form")
    public String postForm(@ModelAttribute("dto") FormDto dto) {
        log.info(dto.getName());
        log.info(String.valueOf(dto.isTrueOrFalse()));
        List<String> hobbies = dto.getHobbies();
        for(String hobby:hobbies){
            log.info(hobby);
        }
        return "form-test/form";
    }

    @ModelAttribute("hobbies") // hobbies에 밑에 만들어둔 map이 들어감 {model.addAttribute("hobbies",map);} 이랑 같음
    // ㄴ 모든 GetMapping에도 model.addAttribute가 자동으로 추가 그래서 단일 GetMapping을 만드는게 좋음
    private Map<String,String> favorite(){
        Map<String, String> map = new HashMap<>();
        map.put("movie","영화보기");
        map.put("music", "음악듣기");
        map.put("game", "게임하기");
        map.put("running", "런닝히기");
        return map;
    }
}
