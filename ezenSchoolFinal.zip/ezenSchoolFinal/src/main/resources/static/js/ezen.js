function check(){
    if(document.getElementById("examNo").value.trim().length == 0){
        alert("학번이이 입력되지 않았습니다.")
        documnet.getElementById("examNo").focus();
        return false
    }
    alert("입력이 완료되었습니다.")
    document.getElementById("frm").submit()
    return true
}