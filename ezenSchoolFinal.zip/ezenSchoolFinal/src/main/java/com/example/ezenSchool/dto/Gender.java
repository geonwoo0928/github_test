package com.example.ezenSchool.dto;

public enum Gender {
    Male,
    Female
}
