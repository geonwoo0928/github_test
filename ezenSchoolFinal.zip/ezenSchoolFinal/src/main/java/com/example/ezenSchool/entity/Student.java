package com.example.ezenSchool.entity;

import com.example.ezenSchool.dto.Gender;
import jakarta.annotation.Nullable;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Student {

    @Id
    @Column(nullable = false , length = 6)
    private String studentNo;

    @Column(length = 10)
    private String name;

    @Column(length = 15)
    private String phone;

    @Enumerated(EnumType.STRING)
    private Gender gender;

    @Column(length = 20)
    private String address;

}
