package com.example.ezenSchool.dto;

import com.example.ezenSchool.entity.Exam;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Range;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExamDto {
    @NotBlank(message = "학번을 입력해주세요.")
    private String examNo;

    @Range(min = 0 , max = 100 , message = "점수는 0점부터 100점까지 입니다." )
    private int kor;

    @Range(min = 0 , max = 100 , message = "점수는 0점부터 100점까지 입니다." )
    private int math;

    @Range(min = 0 , max = 100 , message = "점수는 0점부터 100점까지 입니다." )
    private int eng;

    @Range(min = 0 , max = 100 , message = "점수는 0점부터 100점까지 입니다." )
    private int hist;

    private int examSum;

    private double examAvg;

    private int rank;


    public ExamDto(String examNo, int kor, int math, int eng, int hist) {
        this.examNo = examNo;
        this.kor = kor;
        this.math = math;
        this.eng = eng;
        this.hist = hist;
        this.examSum = kor+math+eng+hist;
        this.examAvg = examSum/4;
    }

    public static ExamDto entityToDto(Exam exam){
        return new ExamDto(
                exam.getExamNo(),
                exam.getKor(),
                exam.getMath(),
                exam.getEng(),
                exam.getHist()
        );
    }
    public static Exam dtoToEntity(ExamDto examDto){
        return new Exam(
                examDto.getExamNo(),
                examDto.getKor(),
                examDto.getMath(),
                examDto.getEng(),
                examDto.getHist()
        );
    }
}
