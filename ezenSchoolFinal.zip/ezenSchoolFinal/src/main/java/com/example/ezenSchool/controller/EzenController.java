package com.example.ezenSchool.controller;

import com.example.ezenSchool.dto.ExamDto;
import com.example.ezenSchool.dto.StudentDto;
import com.example.ezenSchool.dto.TotalAndAvg;
import com.example.ezenSchool.entity.Exam;
import com.example.ezenSchool.service.EzenService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@Slf4j
public class EzenController {
    private final EzenService ezenService;

    public EzenController(EzenService ezenService) {
        this.ezenService = ezenService;
    }

    @GetMapping("/")
    public String main(){
        return "/articles/main";
    } //메인페이지

    @GetMapping("/studentList")
    public String showStudentList(Model model){
        List<StudentDto> studentDtoList = ezenService.showStudentAll();
        model.addAttribute("studentDtoList" , studentDtoList);
        return "/articles/list";
    }

    @GetMapping("/insertScore")
    public String insertScore(Model model , ExamDto examDto){
        model.addAttribute("examDto" , examDto);
        return "/articles/insert";
    }

    @PostMapping("/insertScore")
    public String insert(@Valid @ModelAttribute("examDto") ExamDto examDto , BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            log.info("Validation Error");
            return "/articles/insert";
        }
        ezenService.insertScore(examDto);
        return "/articles/insert";
    }

    @GetMapping("/listScore")
    public String listScoreView(Model model){
        List<StudentDto> studentDtoList =  ezenService.showAll();
        ezenService.rankInsert(studentDtoList); // 등수
        List<StudentDto> sortedList = ezenService.sortedRank(studentDtoList); //등수정렬
        TotalAndAvg total = ezenService.totalAndAvg();
        model.addAttribute("studentDto" , sortedList);
        model.addAttribute("total" , total);
        return "/articles/listScore";
    }
}
