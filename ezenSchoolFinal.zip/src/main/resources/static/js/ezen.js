function check() {
    // 학번 입력 여부 확인
    if (document.getElementById("examNo").value.trim().length == 0) {
        alert("학번이 입력되지 않았습니다.");
        document.getElementById("examNo").focus();
        return false;
    }

    // 각 과목별 점수 범위 확인
    var kor = parseInt(document.getElementById("kor").value.trim());
    var math = parseInt(document.getElementById("math").value.trim());
    var eng = parseInt(document.getElementById("eng").value.trim());
    var hist = parseInt(document.getElementById("hist").value.trim());

    if (isNaN(kor) || kor < 0 || kor > 100 ||
        isNaN(math) || math < 0 || math > 100 ||
        isNaN(eng) || eng < 0 || eng > 100 ||
        isNaN(hist) || hist < 0 || hist > 100) {
        var errorMessage = document.createElement('p');
        errorMessage.style.color = 'red';
        errorMessage.innerHTML = "점수는 0부터 100 사이의 값을 가져야 합니다.";
        document.getElementById("errorMessages").innerHTML = '';
        document.getElementById("errorMessages").appendChild(errorMessage);
        return false;
    }

    // 입력이 완료되었음을 알리고 폼 제출
    alert("입력이 완료되었습니다.");
    document.getElementById("frm").submit();
    return true;
}