package com.example.ezenSchool.service;

import com.example.ezenSchool.dto.ExamDto;
import com.example.ezenSchool.dto.StudentDto;
import com.example.ezenSchool.dto.TotalAndAvg;
import com.example.ezenSchool.entity.Exam;
import com.example.ezenSchool.entity.Student;
import com.example.ezenSchool.repository.ExamRepository;
import com.example.ezenSchool.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EzenService {
    private final StudentRepository studentRepository;
    private final ExamRepository examRepository;

    public EzenService(StudentRepository studentRepository, ExamRepository examRepository) {
        this.studentRepository = studentRepository;
        this.examRepository = examRepository;
    }

    public List<StudentDto> showStudentAll() {
        List<StudentDto> studentDtoList = new ArrayList<>();
        List<Student> studentList = studentRepository.findAll();

        for(Student student : studentList){
            studentDtoList.add(
                StudentDto.entityToDtoCN(student,
                        studentRepository.getClass(student.getStudentNo()),
                        studentRepository.getNum(student.getStudentNo()))
            );
        }
        return studentDtoList;
    } // 학생 전체 출력하는 서비스

    public void insertScore(ExamDto examDto) {
        Exam exam = ExamDto.dtoToEntity(examDto);
        examRepository.save(exam);
    }

    public List<StudentDto> showAll() {
        List<Student> student = studentRepository.findAll();
        List<StudentDto> studentDtoList = new ArrayList<>();

        for(Student studentNew : student ){
            Exam exam = examRepository.findById(studentNew.getStudentNo()).orElse(null);
            if (exam != null) {
                ExamDto examDto = ExamDto.entityToDto(exam);
                studentDtoList.add(
                        StudentDto.entityToDto(studentNew,
                                studentRepository.getClass(studentNew.getStudentNo()),
                                studentRepository.getNum(studentNew.getStudentNo()),
                                examDto)
                );
            } else {
                ExamDto examDto = new ExamDto();
                // 성적이 없는 경우 examDto를 null로 설정하여 StudentDto를 생성
                studentDtoList.add(
                        StudentDto.entityToDtoNoExam(studentNew,
                                studentRepository.getClass(studentNew.getStudentNo()),
                                studentRepository.getNum(studentNew.getStudentNo()),
                                examDto)
                );
            }
        }
        return studentDtoList;
    } //학생성적을 보여줌


    public void rankInsert(List<StudentDto> studentDtoList) {
        for (int i = 0; i < studentDtoList.size(); i++) {
            StudentDto currentStudent = studentDtoList.get(i);
            ExamDto examDto = currentStudent.getExamDto();

            // 현재 학생의 ExamDto가 null이면 처리
            if (examDto == null) {
                continue;
            }
            int rank = 1;
            for (int z = 0; z < studentDtoList.size(); z++) {
                // 현재 학생과 다른 학생을 비교할 때, 두 학생의 ExamDto가 모두 null이 아닌 경우에만 진행
                if (i != z && studentDtoList.get(z).getExamDto() != null) {
                    int currentStudentExamSum = examDto.getExamSum();
                    int otherStudentExamSum = studentDtoList.get(z).getExamDto().getExamSum();

                    // 다른 학생의 점수가 더 높은 경우 등수 증가
                    if (currentStudentExamSum < otherStudentExamSum) {
                        rank++;
                    }
                }
            }
            // 등수 설정
            currentStudent.getExamDto().setRank(rank);
        }
    }


    public TotalAndAvg totalAndAvg(){
        return new TotalAndAvg( examRepository.korSum(),
                                examRepository.mathSum(),
                                examRepository.engSum(),
                                examRepository.histSum(),
                                examRepository.korAvg(),
                                examRepository.mathAvg(),
                                examRepository.engAvg(),
                                examRepository.histAvg());
    }

    public List<StudentDto> sortedRank(List<StudentDto> studentDtoList) {
        Collections.sort(studentDtoList, new Comparator<StudentDto>() {
            @Override
            public int compare(StudentDto o1, StudentDto o2) {
                // 첫 번째 학생의 ExamDto가 null인 경우
                if (o1.getExamDto() == null) {
                    // 두 번째 학생의 ExamDto도 null이면 두 학생을 같은 등수로 처리
                    if (o2.getExamDto() == null) {
                        return 0;
                    } else {
                        // 첫 번째 학생의 ExamDto가 null이면 두 번째 학생을 우선순위로 설정
                        return 1;
                    }
                }
                // 두 번째 학생의 ExamDto가 null인 경우
                else if (o2.getExamDto() == null) {
                    // 두 번째 학생의 ExamDto가 null이면 첫 번째 학생을 우선순위로 설정
                    return -1;
                }
                // 두 학생 모두 ExamDto가 null이 아닌 경우
                else {
                    // 두 학생의 등수 비교
                    return Integer.compare(o1.getExamDto().getRank(), o2.getExamDto().getRank());
                }
            }
        });
        return studentDtoList;
    }

}
