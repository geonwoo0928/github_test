package com.example.ezenSchool.dto;

import com.example.ezenSchool.entity.Student;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentDto {

    private String studentNo;

    private String studentClass;

    private String studentNum;

    private String name;

    private String phone;

    private Gender gender;

    private String address;

    private ExamDto examDto;


    public StudentDto(String studentNo , String studentClass, String studentNum , String name, String phone, Gender gender, String address) {
        this.studentNo = studentNo;
        this.studentClass = studentClass;
        this.studentNum = studentNum;
        this.name = name;
        this.phone = phone;
        this.gender = gender;
        this.address = address;
    }

    public static StudentDto entityToDto(Student student, String num1 , String num2 , ExamDto examDto ){
        return new StudentDto(
                student.getStudentNo(),
                num1,
                num2,
                student.getName(),
                student.getPhone(),
                student.getGender(),
                student.getAddress(),
                examDto
        );
    }
    public static StudentDto entityToDtoNoExam(Student student, String num1 , String num2, Object o){
        return new StudentDto(
                student.getStudentNo(),
                num1,
                num2,
                student.getName(),
                student.getPhone(),
                student.getGender(),
                student.getAddress()
        );
    }
    public static StudentDto entityToDtoCN(Student student,String num1 ,String num2){
        return new StudentDto(
                student.getStudentNo(),
                num1,
                num2,
                student.getName(),
                student.getPhone(),
                student.getGender(),
                student.getAddress()
        ); //반 , 번호
    }

//    public static Student dtoToEntity(StudentDto studentDto){
//        return new Student(
//                studentDto.getStudentNo(),
//                studentDto.getName(),
//                studentDto.getPhone(),
//                studentDto.getGender(),
//                studentDto.getAddress()
//        );
//    }

}
