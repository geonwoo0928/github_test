package com.example.ezenSchool.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TotalAndAvg {
    private int korTotal;
    private int mathTotal;
    private int engTotal;
    private int histTotal;
    private int total;
    private int avg;
    private int korAvg;
    private int mathAvg;
    private int engAvg;
    private int histAvg;
    private int avgTotal;
    private int avgAvg;

    public TotalAndAvg(int korTotal, int mathTotal, int engTotal, int histTotal , int korAvg , int mathAvg , int engAvg , int histAvg) {
        this.korTotal = korTotal;
        this.mathTotal = mathTotal;
        this.engTotal = engTotal;
        this.histTotal = histTotal;
        this.total = korTotal+mathTotal+engTotal+histTotal;
        this.avg = total/4;
        this.korAvg= korAvg;
        this.mathAvg= mathAvg;
        this.engAvg= engAvg;
        this.histAvg= histAvg;
        this.avgTotal = korAvg+mathAvg+engAvg+histAvg;
        this.avgAvg = avgTotal/4;
    }
}