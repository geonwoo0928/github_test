package com.example.ezenSchool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EzenSchoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(EzenSchoolApplication.class, args);
	}

}
