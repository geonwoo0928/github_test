package com.example.ezenSchool.repository;

import com.example.ezenSchool.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentRepository extends JpaRepository<Student, String> {
    @Query(value = "SELECT SUBSTRING(student_no, 2, 2) FROM student WHERE student_no = :studentNo" , nativeQuery = true)
    String getClass(@Param("studentNo") String studentNo); //반 가져오는 sql

    @Query(value = "SELECT SUBSTRING(student_no, 4, 2) FROM student WHERE student_no = :studentNo" , nativeQuery = true)
    String getNum(@Param("studentNo") String studentNo); //번호 가져오는 sql


}
