package com.example.ezenSchool.repository;

import com.example.ezenSchool.entity.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ExamRepository extends JpaRepository<Exam, String> {
    @Query(value = "SELECT COALESCE(SUM(kor), 0) FROM exam" , nativeQuery = true)
    int korSum();

    @Query(value = "SELECT COALESCE(SUM(math), 0) FROM exam" , nativeQuery = true)
    int mathSum();

    @Query(value = "SELECT COALESCE(SUM(eng), 0) FROM exam" , nativeQuery = true)
    int engSum();

    @Query(value = "SELECT COALESCE(SUM(hist), 0) FROM exam" , nativeQuery = true)
    int histSum();

    @Query(value = "SELECT COALESCE(AVG(kor), 0) FROM exam" , nativeQuery = true)
    int korAvg();

    @Query(value = "SELECT COALESCE(AVG(math), 0) FROM exam" , nativeQuery = true)
    int mathAvg();

    @Query(value = "SELECT COALESCE(AVG(eng), 0) FROM exam" , nativeQuery = true)
    int engAvg();

    @Query(value = "SELECT COALESCE(AVG(hist), 0) FROM exam" , nativeQuery = true)
    int histAvg();
}

