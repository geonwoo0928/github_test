package com.example.ezenSchool.repository;

import com.example.ezenSchool.entity.Exam;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ExamRepository extends JpaRepository<Exam, String> {
    @Query(value = "SELECT SUM(kor) FROM exam" , nativeQuery = true)
    int korSum();
    @Query(value = "SELECT SUM(math) FROM exam" , nativeQuery = true)
    int mathSum();
    @Query(value = "SELECT SUM(eng) FROM exam" , nativeQuery = true)
    int engSum();
    @Query(value = "SELECT SUM(hist) FROM exam" , nativeQuery = true)
    int histSum();
}
