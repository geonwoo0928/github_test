package com.example.ezenSchool.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Exam {

    @Id
    @Column(nullable = false , length = 6)
    private String examNo;

    private int kor;

    private int math;

    private int eng;

    private int hist;
}
