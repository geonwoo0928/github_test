package com.example.ezenSchool.controller;

import com.example.ezenSchool.dto.ExamDto;
import com.example.ezenSchool.dto.StudentDto;
import com.example.ezenSchool.entity.Exam;
import com.example.ezenSchool.service.EzenService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class EzenController {
    private final EzenService ezenService;

    public EzenController(EzenService ezenService) {
        this.ezenService = ezenService;
    }

    @GetMapping("/")
    public String main(){
        return "/articles/main";
    } //메인페이지

    @GetMapping("/studentList")
    public String showStudentList(Model model){
        List<StudentDto> studentDtoList = ezenService.showStudentAll();
        model.addAttribute("studentDtoList" , studentDtoList);
        return "/articles/list";
    }

    @GetMapping("/insertScore")
    public String insertScore(Model model , ExamDto examDto){
        model.addAttribute("examDto" , examDto);
        return "/articles/insert";
    }

    @PostMapping("/insertScore")
    public String insert(@ModelAttribute("examDto") ExamDto examDto){
        ezenService.insertScore(examDto);
        return "/articles/listScore";
    }

    @GetMapping("/listScore")
    public String listScoreView(Model model){
        List<StudentDto> studentDtoList =  ezenService.showAll();
        ExamDto examDto = new ExamDto();
        model.addAttribute("studentDto" , studentDtoList);
        return "/articles/listScore";
    }
}
