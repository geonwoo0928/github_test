package com.example.ezenSchool.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TotalAndAvg {
    private int korTotal;
    private int mathTotal;
    private int engTotal;
    private int histTotal;
    private int total;
    private int avg;

    public TotalAndAvg(int korTotal, int mathTotal, int engTotal, int histTotal) {
        this.korTotal = korTotal;
        this.mathTotal = mathTotal;
        this.engTotal = engTotal;
        this.histTotal = histTotal;
        this.total = korTotal+mathTotal+engTotal+histTotal;
        this.avg = total/4;
    }
}
