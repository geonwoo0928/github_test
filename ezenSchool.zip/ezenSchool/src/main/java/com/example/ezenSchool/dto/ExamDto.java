package com.example.ezenSchool.dto;

import com.example.ezenSchool.entity.Exam;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExamDto {

    private String examNo;

    private int kor;

    private int math;

    private int eng;

    private int hist;

    private int examSum;

    private double examAvg;

    private int rank;


    public ExamDto(String examNo, int kor, int math, int eng, int hist) {
        this.examNo = examNo;
        this.kor = kor;
        this.math = math;
        this.eng = eng;
        this.hist = hist;
        this.examSum = kor+math+eng+hist;
        this.examAvg = examSum/4;
    }

    public static ExamDto entityToDto(Exam exam){
        return new ExamDto(
                exam.getExamNo(),
                exam.getKor(),
                exam.getMath(),
                exam.getEng(),
                exam.getHist()
        );
    }
    public static Exam dtoToEntity(ExamDto examDto){
        return new Exam(
                examDto.getExamNo(),
                examDto.getKor(),
                examDto.getMath(),
                examDto.getEng(),
                examDto.getHist()
        );
    }
}
