package com.example.ezenSchool.dto;

import com.example.ezenSchool.entity.Exam;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExamDto {

    private String examNo;

    private int kor;

    private int math;

    private int eng;

    private int hist;

    public static ExamDto entityToDto(Exam exam){
        return new ExamDto(
                exam.getExamNo(),
                exam.getKor(),
                exam.getMath(),
                exam.getEng(),
                exam.getHist()
        );
    }
    public static Exam dtoToEntity(ExamDto examDto){
        return new Exam(
                examDto.getExamNo(),
                examDto.getKor(),
                examDto.getMath(),
                examDto.getEng(),
                examDto.getHist()
        );
    }
}
