package com.example.ezenSchool.service;

import com.example.ezenSchool.dto.ExamDto;
import com.example.ezenSchool.dto.StudentDto;
import com.example.ezenSchool.dto.TotalAndAvg;
import com.example.ezenSchool.entity.Exam;
import com.example.ezenSchool.entity.Student;
import com.example.ezenSchool.repository.ExamRepository;
import com.example.ezenSchool.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Service
public class EzenService {
    private final StudentRepository studentRepository;
    private final ExamRepository examRepository;

    public EzenService(StudentRepository studentRepository, ExamRepository examRepository) {
        this.studentRepository = studentRepository;
        this.examRepository = examRepository;
    }

    public List<StudentDto> showStudentAll() {
        List<StudentDto> studentDtoList = new ArrayList<>();
        List<Student> studentList = studentRepository.findAll();

        for(Student student : studentList){
            studentDtoList.add(
                StudentDto.entityToDtoCN(student,
                        studentRepository.getClass(student.getStudentNo()),
                        studentRepository.getNum(student.getStudentNo()))
            );
        }
        return studentDtoList;
    } // 학생 전체 출력하는 서비스

    public void insertScore(ExamDto examDto) {
        Exam exam = ExamDto.dtoToEntity(examDto);
        examRepository.save(exam);
    }

    public List<StudentDto> showAll() {
        List<Student> student = studentRepository.findAll();
        List<StudentDto> studentDtoList = new ArrayList<>();

        for(Student studentNew : student ){
            ExamDto examDto = ExamDto.entityToDto(examRepository.findById(studentNew.getStudentNo()).orElse(null));
            studentDtoList.add(
                    StudentDto.entityToDto(studentNew,
                            studentRepository.getClass(studentNew.getStudentNo()),
                            studentRepository.getNum(studentNew.getStudentNo()),
                            examDto)
            );
        }
        return studentDtoList;
    } //학생성적 보여줌

    public void rankInsert(List<StudentDto> studentDtoList){
        int i , z;
        int rank;
        for(i=0; i<studentDtoList.size(); i++){
            rank = 1;
            for(z=0; z<studentDtoList.size(); z++){
                if(i != z){
                    if(studentDtoList.get(i).getExamDto().getExamSum() < studentDtoList.get(z).getExamDto().getExamSum()){
                        rank++;
                    }
                }
            }
            studentDtoList.get(i).getExamDto().setRank(rank);
        }
    }//학생등수

    public TotalAndAvg total(){
        return new TotalAndAvg( examRepository.korSum(),
                                examRepository.mathSum(),
                                examRepository.engSum(),
                                examRepository.histSum());
    }

}
