package com.example.jpaTest.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Team {
    @Id
    private String teamId;
    private String teamName;
    @OneToMany(mappedBy = "team" , fetch = FetchType.LAZY)
    private List<Member> memberList = new ArrayList<>();


    public Team(String teamId, String teamName) {
        this.teamId = teamId;
        this.teamName = teamName;
    }
}
