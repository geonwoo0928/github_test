package com.example.jpaTest.service;

import com.example.jpaTest.entity.Member;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class ContextService {
    @Autowired
    EntityManager em; //Repository 역할

    public Member memberInsert(){
        Member member = new Member();
        member.setMemberId("안유진");
        member.setName("유진");
        em.persist(member);
        Member m = em.find(Member.class , "안유진" );
        return m;
    }

    public void transactionTest(){
        Member member = new Member();
        member.setMemberId("홍길동");
        member.setName("길동");

        Member member1 = new Member();
        member1.setMemberId("이순신");
        member1.setName("순신");

        em.persist(member);
        em.find(Member.class , "홍길동");
        System.out.println(member);

        em.persist(member1);
        em.find(Member.class , "이순신");
        System.out.println(member1);

        em.flush(); //transaction이 종료되면 저장시키는 메소드
    }

    public void dirtyChecking(){
        // 영속 엔티티 조회
        Member member = em.find(Member.class , "안유진");
        // 데이터 수정
        member.setName("YuJin"); //변경감지
        System.out.println(member);
    }

    public void deleteCheck(){
        Member member = em.find(Member.class,"안유진");
        em.remove(member); //delete
    }
}
