package com.example.jpaTest.service;

import com.example.jpaTest.entity.Child;
import com.example.jpaTest.entity.Member;
import com.example.jpaTest.entity.Parent;
import com.example.jpaTest.entity.Team;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class RelationTestService {
    @Autowired
    EntityManager em;

    public void insertMemberAndTeam(){
        Member member = new Member();
        member.setMemberId("장원영");
        member.setName("원영");
        member.getTeam().setTeamId("ive");
        em.persist(member); // 새로운 멤버 생성 후 저장

        Team team = new Team();
        team.setTeamId("ive");
        team.setTeamName("아이브");
        em.persist(team); //
    }

//    public void insertMemberAndTeamRelation(){
//        Team team = new Team("ive" , "아이브" );
//        em.persist(team);
//        Member member = new Member ("장원영" , "원영" , team);
//        em.persist(member);
//    }

    public void insertBothDirectionRelation(){
        Team team = new Team("NewJeans" , "뉴진스");
        em.persist(team);

        Member member1 = new Member("GeonWoo" , "건우" ,team);
        em.persist(member1);
        Member member2 = new Member("Ozllzlu" , "예진" ,team);
        em.persist(member2);
        Member member3 = new Member("Wecky" , "가연" ,team);
        em.persist(member3);

    }

    public void saveNoCascade(){
        //1번 부모저장
        Parent parent = new Parent();
        em.persist(parent);

        //1번 자식저장
        Child child = new Child();
        child.setParent(parent);
        parent.getChildList().add(child);
        em.persist(child);

        //2번 자식저장
        Child child2 = new Child();
        child2.setParent(parent);
        parent.getChildList().add(child2);
        em.persist(child2);

    }

    public void saveCascade(){
        Child child1 = new Child();
        Child child2 = new Child();

        Parent parent = new Parent();
        child1.setParent(parent);
        child2.setParent(parent);
        parent.getChildList().add(child1);
        parent.getChildList().add(child2);

        em.persist(parent);
    }

    public void cascadeDelete(){
        Parent parent = em.find(Parent.class , 1L);
        em.remove(parent);
    }
}
