package com.example.jpaTest.service;

import com.example.jpaTest.dto.MemberDto;
import com.example.jpaTest.entity.Member;
import com.example.jpaTest.entity.Team;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
public class QueryService {
    @Autowired
    EntityManager em;

    //동적쿼리 생성해서 장원영 검색하기
    public List<Member> dynamicQuery() {
        String sql = "SELECT m FROM Member m WHERE m.memberId=:id";
        TypedQuery<Member> query = em.createQuery(sql, Member.class)
                .setParameter("id", "GeonWoo");
        List<Member> memberList = query.getResultList();
        return memberList;
    }

    //동적쿼리 생성해서 팀 전체 검색하기
    public List<Team> findAllTeam() {
        String sql = "SELECT t FROM Team t";
        Query query = em.createQuery(sql);
        List<Team> teamList = query.getResultList();
        return teamList;
    }

    //Member table 에서 멤버 이름만 검색
    public List<String> findMemberName() {
        String sql = "SELECT m.name FROM Member m";
        TypedQuery<String> query = em.createQuery(sql,String.class);
        List<String> nameList = query.getResultList();
        return nameList;
    }

    //멤버 테이블 중 newJeans 소속 멤버의 이름만 출력
    public List<String> findNewJeansMemberName(){
        String sql = "SELECT m.name FROM Member m WHERE m.team.teamName = :teamname";
        TypedQuery<String> query = em.createQuery(sql,String.class).setParameter("teamname" , "뉴진스");
        List<String> nameList = query.getResultList();
        return nameList;
    }

    // 뉴진스의 멤버의 인원수를 구하기
    public long newJeansMemberCount(){
        String sql = "SELECT COUNT(m) FROM Member m WHERE m.team.teamName = :teamname";
        TypedQuery<Long> query = em.createQuery(sql,Long.class).setParameter("teamname" , "뉴진스");
        long memberCount = query.getSingleResult();
        return memberCount;
    }

    // 멤버 이름과 팀 이름을 DTO 리스트로 받기
    public List<MemberDto> findMemberNameAndTeamName(){
        String sql = "SELECT NEW MemberDto(m.name , m.team.teamName) FROM Member m";
        TypedQuery<MemberDto> query = em.createQuery(sql , MemberDto.class);
        List<MemberDto> memberDtos = query.getResultList();
        return memberDtos;
    }

    //namedQuery 실행하기
    public List<Member> findMemberNameNamedQuery(){
        TypedQuery<Member> memberTypedQuery = em.createNamedQuery("Member.findByMemberName" , Member.class)
                .setParameter("userName" , "건우");
        List<Member> memberList = memberTypedQuery.getResultList();
        return memberList;
    }

    //NativQuery Test
    //뉴진스의 멤버이름 , 팀이름을 Member, Team 테이블을 조인해서 출력합니다.
    public List<MemberDto> findNativeQuery(){
        String sql = "SELECT m.name , t.team_name FROM member as m JOIN team as t ON m.team_id = t.team_id WHERE t.team_id = :teamId";
        NativeQuery<MemberDto> query = (NativeQuery<MemberDto>) em.createNativeQuery(sql,MemberDto.class).setParameter("teamId" , "NewJeans");
        List<MemberDto> memberDtoList = query.getResultList();
        return memberDtoList;
    }
}
