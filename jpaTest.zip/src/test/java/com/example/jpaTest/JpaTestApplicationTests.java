package com.example.jpaTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
