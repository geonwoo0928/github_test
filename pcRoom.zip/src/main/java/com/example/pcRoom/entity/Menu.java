package com.example.pcRoom.entity;

import jakarta.persistence.*;

@Entity
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long menuId;

    @Column(nullable = false)
    private String menuName;

    @Column(nullable = false)
    private int menuAmount;

    @Column(nullable = false)
    private int menuPrice;
}
