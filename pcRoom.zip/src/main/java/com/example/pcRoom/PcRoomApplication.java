package com.example.pcRoom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PcRoomApplication {

	public static void main(String[] args) {
		SpringApplication.run(PcRoomApplication.class, args);
	}

}
