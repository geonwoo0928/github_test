package com.example.pcRoom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcRoomApplicationTests {

	@Test
	void contextLoads() {
	}

}
