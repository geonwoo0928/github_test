package com.example.basiccrud.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name="member")
@Data
public class Member {
    @Id //Primary key
    @GeneratedValue(strategy = GenerationType.AUTO) //자동증가
    private Long id;

    @Column(length = 20, nullable = false) //길이 20 , NotNull
    private String name;

    private int age;

    @Column(name = "address" , length = 100) //DB안에 이름 address , 길이 100
    private String addr;


}
