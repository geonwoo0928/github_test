package com.example.myBoard.repository;

import com.example.myBoard.entity.Article;
import jakarta.transaction.Transactional;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Transactional // 테스트 끝낸 후 롤백
@TestPropertySource(locations = "classpath:application-test.properties") //classpath -> resources
class ArticleRepositoryTest {
    @Autowired
    ArticleRepository articleRepository;

    @Test
    void 모든데이터검색_클래스_실패() {
        //Given
        Article article1 = new Article(1L, "라라라", "1111");
        Article article2 = new Article(2L, "나나나", "2222");
        Article article3 = new Article(3L, "다다다", "3333");
        List<Article> expectList = new ArrayList<>();
        expectList.add(article1);
        expectList.add(article2);
        expectList.add(article3);
        //When
        List<Article> resultList = articleRepository.findAll();
        //Then
        assertThat(resultList.toString()).isNotEqualTo(expectList.toString());
    }

    @Test
    void 모든데이터검색_클래스_성공() {
        //Given
        Article article1 = new Article(1L, "가가가", "1111");
        Article article2 = new Article(2L, "나나나", "2222");
        Article article3 = new Article(3L, "다다다", "3333");
        List<Article> expectList = new ArrayList<>();
        expectList.add(article1);
        expectList.add(article2);
        expectList.add(article3);
        //When
        List<Article> resultList = articleRepository.findAll();
        //Then
        assertThat(resultList.toString()).isEqualTo(expectList.toString());
    }

    @Test
     void 전체데이터검색_갯수() {
        //Given
        int expectCount = 3;
        //When
        int resultCount = articleRepository.findAll().size();
        //Then
        assertThat(resultCount).isEqualTo(expectCount);
    }

    @Test
    void 자료입력테스트_성공(){
        //Given
        Article expectArticle = new Article(4L,"랄랄랄","4444");
        //When
        Article newArticle = new Article(null,"랄랄랄","4444");
        articleRepository.save(newArticle);
        //Then
        Article resultArticle = articleRepository.findById(4L).get();
//        Article resultArticle = articleRepository.findById(4L).orElse(null);
        assertThat(resultArticle.toString()).isEqualTo(expectArticle.toString());
        //          기대하는 값
    }

    @Test
    void 자료삭제테스트_성공(){
        //Given
        Long deleteId = 4L;
        //When
        articleRepository.deleteById(deleteId);
        //Then
        Article resultArticle = articleRepository.findById(deleteId).orElse(null);
        assertThat(resultArticle).isEqualTo(null);
    }

    @Test
    void 자료수정테스트(){
        //Given
        Article expectArticle = new Article(1L,"수정","수정");
        //When
        Article updateArticle = new Article(1L,"수정","수정");
        articleRepository.save(updateArticle);
        Article article = articleRepository.findById(1L).orElse(null);
        //Then
        assertThat(article.toString()).isEqualTo(expectArticle.toString());
    }
}