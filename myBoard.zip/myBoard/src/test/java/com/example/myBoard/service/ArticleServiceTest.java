package com.example.myBoard.service;

import com.example.myBoard.dto.ArticleDto;
import jakarta.transaction.Transactional;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
@TestPropertySource(locations = "classpath:application-test.properties")
class ArticleServiceTest {
    @Autowired
    ArticleService articleService;

    @Test
    @DisplayName("전체데이터_읽기")
    void showAll() {
        //Given
        int totalCount = 3;
        //When
//        int resultTotalCount = articleService.showAll().size();
        List<ArticleDto> lists = articleService.showAll();
        int resultTotalCount = lists.size();
        //Then
        assertThat(resultTotalCount).isEqualTo(totalCount);
    }

    @Test
    @DisplayName("자료입력_테스트")
    void insertData() {
        //Given
        ArticleDto expectDto = new ArticleDto(4L,"라라라","444");
        //When
        articleService.insertData(new ArticleDto(null, "라라라", "444"));
        //Then
        assertThat(articleService.findOne(4L).getTitle()).isEqualTo("라라라");
        assertThat(articleService.findOne(4L).getContent()).isEqualTo("444");
    }

    @Test
    @DisplayName("단건자료검색_테스트")
    void findOne() {
        //Given
        ArticleDto expectDto = new ArticleDto(2L,"나나나","222");
        //When
        ArticleDto resultDto = articleService.findOne(2L);
        //Then
        assertThat(resultDto.toString()).isEqualTo(expectDto.toString());
    }

    @Test
    void update() {
        //Given
        ArticleDto expectDto = new ArticleDto(2L ,"라라라" , "123");
        //When
        articleService.update(new ArticleDto(2L , "라라라", "123"));
        ArticleDto resultDto = articleService.findOne(2L);
        //Then
        assertThat(resultDto.toString()).isEqualTo(expectDto.toString());
    }

    @Test
    void delete() {
        //Given
        Long deleteId = 2L;
        //When
        articleService.delete(deleteId);
        //Then
        ArticleDto articleDto = articleService.findOne(deleteId);
        assertThat(articleDto).isEqualTo(null);
    }
}