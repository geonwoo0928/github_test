package com.example.myBoard.repository;

import com.example.myBoard.constant.Gender;
import com.example.myBoard.entity.Users;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.TestPropertySource;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
@Transactional
@TestPropertySource(locations = "classpath:application-test.properties")
class UsersRepositoryTest {

    @Autowired
    UsersRepository usersRepository;

    @Test
    public void findByName테스트() {
        String findName = "김예진";
        usersRepository.findByName(findName).forEach(users -> System.out.println(users));
    }

    @Test
    void findTop3ByLikeColor테스트() {
        String color = "Pink";
        usersRepository.findTop3ByLikeColor(color).forEach(users -> System.out.println(users));
    }

    @Test
    void findByGenderAndLikeColor테스트() {
        Gender gender = Gender.Male;
        String color = "pink";

        usersRepository.findByGenderAndLikeColor(gender, color).forEach(users -> System.out.println(users));
    }

//    @Test
//    void findByCreatedAtAfter테스트() {
//        usersRepository.findByCreatedAtAfter(LocalDateTime.now().minusDays(10L)).forEach(users -> System.out.println(users));
//    }

//    @Test
//    void findByColorAndSort테스트(){
//        String color = "Orange";
//        usersRepository.findByLikeColor(color , Sort.by(Sort.Order.asc("gender"),Sort.Order.desc("createAt"))).forEach(users -> System.out.println(users));
//    }

    //전체 페이징 처리
    @Test
    void pagingTest() {
        System.out.println("페이지 = 0 , 페이지당 리스트 수 : 5");
        usersRepository.findAll(
                        PageRequest.of(0, 5, Sort.by(Sort.Order.desc("id"))))
                .getContent()
                .forEach(users -> System.out.println(users));
        System.out.println("페이지 = 1 , 페이지당 리스트 수 : 5");
        usersRepository.findAll(
                        PageRequest.of(1, 5, Sort.by(Sort.Order.desc("id"))))
                .getContent()
                .forEach(users -> System.out.println(users));
        System.out.println("페이지 = 2 , 페이지당 리스트 수 : 5");
        usersRepository.findAll(
                        PageRequest.of(2, 5, Sort.by(Sort.Order.desc("id"))))
                .getContent()
                .forEach(users -> System.out.println(users));
        System.out.println("페이지 = 3 , 페이지당 리스트 수 : 5");
        usersRepository.findAll(
                        PageRequest.of(3, 5, Sort.by(Sort.Order.desc("id"))))
                .getContent()
                .forEach(users -> System.out.println(users));
    }

    @Test
    void findByIdGreaterThanEqualOrderByDesc테스트() {
        Pageable pageable = PageRequest.of(4, 10);
        Page<Users> result = usersRepository.findByIdGreaterThanEqualOrderByIdDesc(
                200L, pageable);

        result.getContent().forEach(users -> System.out.println(users));

        //전체 페이지 수
        System.out.println("Total Pages " + result.getTotalPages());

        //전체 데이터 개수
        System.out.println("Total Data" + result.getTotalElements());

        //현재 페이지 번호
        System.out.println("Current Page" + result.getNumber());

        //다음 페이지 존재 여부
        System.out.println("Next Page " + result.hasNext());

        //시작 페이지인지 여부
        System.out.println("Is Start Page" + result.isFirst());
    }

    @Test
    void findByGenderAndNameContains테스트() {
        ArrayList<String> name = new ArrayList<>();
        name.add("m");
        name.add("w");
        name.forEach(name1 -> {
            usersRepository.findByGenderAndNameContains(Gender.Female, name1).forEach(users -> System.out.println(users));
        });
    } //1번 문제

    @Test
    void findByEmailContains테스트(){
        System.out.println(usersRepository.findByEmailContains("net").size());;
    } //2번 문제

    @Test
    void findByCreatedAtBetweenAndNameStartingWith테스트(){
        usersRepository.findByUpdatedAtBetweenAndNameStartingWith(LocalDateTime.now().minusMonths(1L), LocalDateTime.now() ,"J").forEach(users -> System.out.println(users));
    } //3번 문제

    @Test
    void findTop10ByCreatedAtBetween테스트(){
        usersRepository.findTop10ByOrderByCreatedAtDesc().forEach(users -> System.out.println(users.getId() + " " + users.getName() + " " + users.getGender() + " " + users.getCreatedAt()));
    } //4번 문제

    @Test
    void findByLikeColor테스트(){
        List<String> list = new ArrayList<>();
        usersRepository.findByGenderAndLikeColor(Gender.Male,"Red").forEach(users -> list.add(users.getEmail()));
        for(String email : list){
            int atIndex = email.indexOf("@");
            String username = email.substring(0, atIndex);
            System.out.println(username);
        }
    } //5번 문제

    @Test
    void findByCreatedAtAfterAndUpdateAtAfter테스트(){
        List<Users> usersList = usersRepository.findAll();
        List<Users> usersList1 = new ArrayList<>();
        for(Users users : usersList){
            if(users.getCreatedAt().isAfter(users.getUpdatedAt())){
                usersList1.add(users);

            }
        }
        for(Users users : usersList1){
            System.out.println(users);
        }
    }//6번 문제

    @Test
    void findByEmailContainsAndGenderOrderByCreatedAtDesc테스트(){
        usersRepository.findByEmailContainsAndGenderOrderByCreatedAtDesc("edu" , Gender.Female).forEach(users -> System.out.println(users));
    }//7번 문제

    @Test
    void findByOrderByColorAscNameDesc테스트(){
        usersRepository.findByOrderByLikeColorAscNameDesc().forEach(users -> System.out.println(users));
    }//8번 문제

    @Test
    void findByOrderByUpdatedAtDesc테스트(){
        Pageable pageable = PageRequest.of(0,10);
        Page<Users> results = usersRepository.findByOrderByUpdatedAtDesc(pageable);
        results.getContent().forEach(users -> System.out.println(users));
    }//9번 문제

    @Test
    void findByGenderOrderByIdDesc테스트(){
        Pageable pageable = PageRequest.of(1,3);
        Page<Users> results = usersRepository.findByGenderOrderByIdDesc(Gender.Male , pageable);
        results.getContent().forEach(users -> System.out.println(users));
    }//10번 문제

    @Test
    void findByUpdatedAtGreaterThanEqual테스트(){
        usersRepository.findByUpdatedAtGreaterThanEqual(LocalDateTime.now().minusMonths(1L)).forEach(users -> System.out.println(users));
    }//11번 문제
}