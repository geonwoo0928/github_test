insert into article(title, content) values ('가가가', '1111');
insert into article(title, content) values ('나나나', '2222');
insert into article(title, content) values ('다다다', '3333');