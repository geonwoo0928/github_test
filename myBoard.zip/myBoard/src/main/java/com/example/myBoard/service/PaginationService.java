package com.example.myBoard.service;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.IntStream;

@Service
public class PaginationService {
    private static final int BAR_LENGTH = 5;
    public List<Integer> getPaginationBarNumbers(int currentPageNumber , int totalPageNumber){
        int startNum = Math.max(currentPageNumber - (BAR_LENGTH/2),0); //(currentPageNumber - (BAR_LENGTH/2),0) 둘중에 하나 골라서 더 큰값을 출력
        int endNum = Math.min(startNum + BAR_LENGTH,totalPageNumber);
        return IntStream.range(startNum , endNum).boxed().toList(); //boxed() 맨 마지막 숫자 뺌
    }
}
