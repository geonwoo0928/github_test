package com.example.myBoard.service;

import com.example.myBoard.dto.ArticleDto;
import com.example.myBoard.entity.Article;
import com.example.myBoard.repository.ArticleRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ArticleService {
    public final ArticleRepository articleRepository;


    public ArticleService(ArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    public List<ArticleDto> showAll(){
        List<ArticleDto> dtoList = new ArrayList<>();
        List<Article> entityList = articleRepository.findAll();
        for(Article article : entityList){
            dtoList.add(
                    ArticleDto.EntityToDto(article)
            );
        }
        return dtoList;
    }

    public void insertData(ArticleDto articleDto){
        Article articleEntity = ArticleDto.DtoToEntity(articleDto);
        articleRepository.save(articleEntity);
    }// 데이터 저장

    public ArticleDto findOne(Long id) {
        Article article= articleRepository.findById(id).orElse(null);
        if(article==null){
            return null;
        } else
            return ArticleDto.EntityToDto(article);
    }

    public void update(ArticleDto dto) {
        Article article = ArticleDto.DtoToEntity(dto);
        articleRepository.save(article);

    }

    public void delete(Long id) {
        articleRepository.deleteById(id);
    }

    public Page<Article> pagingList(Pageable pageable) {
        return articleRepository.findAll(pageable);
    }
}
