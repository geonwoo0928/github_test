INSERT INTO `student`.`student` (`student_no`, `name`, `phone`, `address`, `gender`) VALUES ('10101', '김행복', '010-1111-2222', '서울 동대문구 휘경 1동', 'Male');
INSERT INTO `student`.`student` (`student_no`, `name`, `phone`, `address`, `gender`) VALUES ('10102', '이축복', '010-1111-3333', '서울 동대문구 휘경2동', 'Female');
INSERT INTO `student`.`student` (`student_no`, `name`, `phone`, `address`, `gender`) VALUES ('10103', '장믿음', '010-1111-4444', '울릉군 울릉읍 독도1리', 'Male');
INSERT INTO `student`.`student` (`student_no`, `name`, `phone`, `address`, `gender`) VALUES ('10104', '최사랑', '010-1111-5555', '울릉군 울릉읍 독도2리', 'Female');
INSERT INTO `student`.`student` (`student_no`, `name`, `phone`, `address`, `gender`) VALUES ('10105', '김예진', '010-1111-6666', '경기도 파주시', 'Male');
INSERT INTO `student`.`student` (`student_no`, `name`, `phone`, `address`, `gender`) VALUES ('10106', '우가연', '010-1111-7777', '경기도 고양시', 'Male');
