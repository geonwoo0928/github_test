package com.example.basiccrud.service;

import com.example.basiccrud.dto.MemberDto;
import com.example.basiccrud.entity.Member;
import com.example.basiccrud.repository.MemberRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class MemberService {
    private final MemberRepository memberRepository;

    public MemberService(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    public  List<MemberDto> searchMember(String type, String keyword) {
        List<MemberDto> memberDtoList = new ArrayList<>();
        switch (type){
            case "name" : //이름으로
                memberDtoList = memberRepository.searchName(keyword)
                        .stream()
                        .map(x -> MemberDto.fromMemberEntity(x))
                        .toList();
                break;
            case "addr" : //주소로
                memberDtoList = memberRepository.searchAddr(keyword)
                        .stream()
                        .map(x -> MemberDto.fromMemberEntity(x))
                        .toList();
                break;
            default:        // 검색내용선택 (전체)
                memberDtoList = memberRepository.searchQuery()
                        .stream()
                        .map(x -> MemberDto.fromMemberEntity(x))
                        .toList();
                break;
        }
        return memberDtoList;
    }


    public List<MemberDto> showAllMembers() {
        List<MemberDto> memberDtoList = new ArrayList<>();
        List<Member> memberList = memberRepository.findAll();
        //repository -> dto [두번째 방법] MemberDto에 static 메소드로 사용하는 법
        //repository -> dto [두번째 방법] MemberDto에 static 메소드로 사용하는 법
        for (Member member : memberList) {
            memberDtoList.add(
                    MemberDto.fromMemberEntity(member)
            );
        }
        return memberDtoList;
    } //전체를 보여줌


    public  void insertMember(MemberDto dto) {
        Member member = dto.fromMemberDto(dto);
        memberRepository.save(member);
    }

    public MemberDto getOneMember(Long id) {
        Member member = memberRepository.findById(id).orElse(null);
        MemberDto dto = MemberDto.fromMemberEntity(member);

        return dto;
    }


    public void update(MemberDto dto) {
        Member member = dto.fromMemberDto(dto);
        memberRepository.save(member);
    }

    public void delete(Long id) {
        memberRepository.deleteById(id);
    }

}
