package com.example.basiccrud.controller;

import com.example.basiccrud.dto.MemberDto;
import com.example.basiccrud.entity.Member;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.example.basiccrud.repository.MemberRepository;
import com.example.basiccrud.service.MemberService;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/member")
@Slf4j
public class MemberController {
    private final MemberService memberService;

    public MemberController( MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("show")
    public String showAll(Model model){
        List<MemberDto> memberDtoList = memberService.showAllMembers();
//        List<Member> memberList = memberRepository.findAll(); // preparement,result 자동으로
//        //repository -> dto [두번째 방법] MemberDto에 static 메소드로 사용하는 법
//        List<MemberDto> dtoList = new ArrayList<>();
//        for(Member member : memberList){
//            dtoList.add(
//                    MemberDto.fromMemberEntity(member)
//            );
//        }
        //repository -> dto [두번째 방법] MemberDto에 static 메소드로 사용하는 법
        model.addAttribute("memberDto", memberDtoList);

        return "showMember";
    }

    @GetMapping("/insertForm")
    public String insertForm(Model model){
        model.addAttribute("memberDto", new MemberDto());
        return "/insertForm";
    }

    @PostMapping("/insert") //@Valid 선언되고 BindingResult 선언해야함
    public String insert(@Valid @ModelAttribute("memberDto") MemberDto dto, BindingResult bindingResult) {
        if(bindingResult.hasErrors()){ //Validation 오류확인
            log.info("Validation Error");
            return "insertForm";
        }
        memberService.insertMember(dto); // 저장해주는 멤버
//          log.info(dto.toString());
//         가져온 DTO를 Entity Member class 옮겨 담기
//        Member member = dto.fromMemberDto(dto);
//        memberRepository.save(member);
        return "redirect:/member/show";
    }

    @GetMapping("/update")
    public String updateMember(@RequestParam("updateId") Long id, Model model){

        MemberDto memberDto = memberService.getOneMember(id);
//        log.info("-----------------"+String.valueOf(id));
        //가져온 ID를 데이터베이스에서 검색
        //Optional 데이터베이스를 접근해서 가져와 해당하는 데이터베이스에 그 자료가 없을때 null을 대처하기 나온 기능
        //orElse 데이터베이스에 데이터가 없을때 ()안에 있는 값을 출력
//        Member member = memberRepository.findById(id).orElse(null);
        //검색한 결과를 MemberDto에 옮겨 담기
//        MemberDto dto = MemberDto.fromMemberEntity(member);
        //dto를 모델에 담아서 updateForm 전송

        //위 두가지를 한번에 처리하기
//        MemberDto memberDto = memberRepository.findById(id).map(x -> MemberDto.fromMemberEntity(x)).orElse(null);
        model.addAttribute("memberDto", memberDto);
        return "/updateForm";
    }

    @PostMapping("/update")
    public String update(@Valid @ModelAttribute("memberDto") MemberDto dto ,BindingResult bindingResult ){
        if(bindingResult.hasErrors()){ //Validation 오류확인
            log.info("Validation Error");
            return "updateForm";
        }
        memberService.update(dto);
//        log.info("Update" + dto.toString());
        //1. dto를 entity로 변경
//        Member member = dto.fromMemberDto(dto);
//
//        //2. 저장
//        memberRepository.save(member);
        return "redirect:/member/show";
    }

    //삭제 처리
    @PostMapping("/delete/{deleteId}")
//    public String delete(@RequestParam("deleteId") Long id){
    public String delete(@PathVariable("deleteId") Long id){

        memberService.delete(id);

//        memberRepository.deleteById(id);
        return "redirect:/member/show";
    }

    //검색처리하기
    @GetMapping("/search")
    public String searchMember(@RequestParam("type") String type ,
                               @RequestParam("keyword") String keyword,
                               Model model){
//        log.info(type);
//        log.info(keyword);

        List<MemberDto> memberDtoList= memberService.searchMember(type, keyword);

//        List<MemberDto> memberDtoList = new ArrayList<>();
//
//        switch (type){
//            case "name" : //이름으로
//                memberDtoList = memberRepository.searchName(keyword)
//                        .stream()
//                        .map(x -> MemberDto.fromMemberEntity(x))
//                        .toList();
//                break;
//            case "addr" : //주소로
//                memberDtoList = memberRepository.searchAddr(keyword)
//                        .stream()
//                        .map(x -> MemberDto.fromMemberEntity(x))
//                        .toList();
//                break;
//            default:        // 검색내용선택 (전체)
//                memberDtoList = memberRepository.searchQuery()
//                        .stream()
//                        .map(x -> MemberDto.fromMemberEntity(x))
//                        .toList();
//                break;
//        }
        model.addAttribute("memberDto", memberDtoList);
        return "/showMember";
    }
}
