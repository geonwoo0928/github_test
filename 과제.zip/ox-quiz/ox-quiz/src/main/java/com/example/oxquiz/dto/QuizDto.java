package com.example.oxquiz.dto;

import com.example.oxquiz.entity.QuizEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuizDto {
    private Long id;
    private String content;
    private String answer;
    private String name;

    public static QuizDto fromQuizEntity(QuizEntity quizEntity) {
        return new QuizDto(
                quizEntity.getId(),
                quizEntity.getContent(),
                quizEntity.getAnswer(),
                quizEntity.getName()
        );
    }
}
