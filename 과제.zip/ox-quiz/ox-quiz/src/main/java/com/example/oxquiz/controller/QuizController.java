package com.example.oxquiz.controller;

import com.example.oxquiz.dto.QuizDto;
import com.example.oxquiz.service.QuizSerivce;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
@Slf4j
public class QuizController {
    private final QuizSerivce quizSerivce;

    public QuizController(QuizSerivce quizSerivce) {
        this.quizSerivce = quizSerivce;
    }

    @GetMapping("/main")
    public String main(){
        return "/index";
    }//메인페이지 GetMapping

    @GetMapping("/submit")
    public String submitView(){
        return "/submit";
    }//등록페이지 GetMapping

    @GetMapping("/update")
    public String updateView(){
        return "/update";
    }//갱신페이지 GetMapping

    @GetMapping("/delete")
    public String deleteView(){
        return "/delete";
    }//삭제페이지 GetMapping

    @GetMapping("/quizList")
    public String quizList(Model model){
        List<QuizDto> quizDtoList = quizSerivce.showAll();

        model.addAttribute("quizDtoList", quizDtoList);
        return "/quizList";
    }//퀴즈목록페이지 GetMapping
    @GetMapping("play")
    public String playView(){
        return "play";
    }//게임페이지 GetMapping
}
