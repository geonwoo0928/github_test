package com.example.oxquiz.dto;


import lombok.Getter;

@Getter
public enum OorX {
    YES("O") ,NO("X");

    private final String description;

    OorX(String description) {
        this.description = description;
    }
}
