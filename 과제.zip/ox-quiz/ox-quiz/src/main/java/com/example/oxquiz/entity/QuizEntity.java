package com.example.oxquiz.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name="quiz")
@Data
public class QuizEntity {
    @Id //Primary key
    @GeneratedValue(strategy = GenerationType.AUTO) //자동증가
    private Long id;

    @Column(length = 255 , nullable = false)
    private String content;

    @Column(length = 255 , nullable = false)
    private String answer;

    @Column(length = 10 , nullable = false)
    private String name;
}
