package com.example.oxquiz.service;

import com.example.oxquiz.dto.QuizDto;
import com.example.oxquiz.entity.QuizEntity;
import com.example.oxquiz.repository.QuizRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class QuizSerivce {
    private final QuizRepository quizRepository;

    public QuizSerivce(QuizRepository quizRepository) {
        this.quizRepository = quizRepository;
    }

    public List<QuizDto> showAll() {
        List<QuizDto> quizDtoList = new ArrayList<>();
        List<QuizEntity> quizEntityList = quizRepository.findAll();

        for (QuizEntity quizEntity : quizEntityList){
            quizDtoList.add(
                    QuizDto.fromQuizEntity(quizEntity)
            );
        }
        return quizDtoList;
    } // 퀴즈 전체 목록을 출력하는 메소드
}
