package dto;


import com.example.basiccrud.entity.Member;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data

public class MemberDto {
    private Long id;
    private String name;
    private int age;
    private String myAddress;

    public static MemberDto fromMemberEntity(Member member){
        return new MemberDto(
                member.getId(),
                member.getName(),
                member.getAge(),
                member.getMyAddress()
        );
    }
}
