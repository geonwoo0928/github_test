package com.example.basiccrud.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name="member")
@Data
public class Member {
    @Id // Primary Key
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO) //AI MySQL-> IDENTITY,AUTO
    private Long id;

    @Column(name = "name", length = 40, nullable = false)
    private String name;

    private int age;

    private String myAddress;
}
