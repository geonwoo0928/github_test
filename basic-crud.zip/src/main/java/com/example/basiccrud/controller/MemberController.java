package com.example.basiccrud.controller;

import com.example.basiccrud.entity.Member;
import com.example.basiccrud.repository.MemberRepository;
import dto.MemberDto;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("member")
@Slf4j
@ToString
public class MemberController {
    // 1. 생성자로 주입하기 (권장)
    private final MemberRepository memberRepository;

    public MemberController(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    //2. Autowired로 주입하기
//    @Autowired
//    private MemberRepository memberRepository;

    @GetMapping("view")
    public String showMember(Model model){
        //전체 member 테이블 가져오기
//        List<Member> memberList = memberRepository.findAll(); //memberList 를 가져오는 메소드 findAll()
        List<MemberDto> memberDtoList = new ArrayList<>();
//        for(Member member : memberList){
//            memberDtoList.add(MemberDto.fromMemberEntity(member));
//        }
        //스트림을 이용해서 처리하기
        List<MemberDto> dtoList = memberRepository
                .findAll()
                .stream()
                .map(x -> MemberDto.fromMemberEntity(x))
                .toList();

        log.info(dtoList.toString());
        model.addAttribute("dtoList" , dtoList);
        model.addAttribute("title", "회원정보");
        //모델에 담아서 보내기
        return "showMember";
    }
    @GetMapping("insert")
    public String insertFormView(Model model){
        model.addAttribute("dto",new MemberDto());
        return "insertForm";
    }
}
