package com.example.myBoard.config;

import com.example.myBoard.entity.UserAccount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;

public class PrincipalDetails implements UserDetails {
    private UserAccount user;

    public PrincipalDetails(UserAccount user) {
        this.user = user;
    }

    public UserAccount getUser() {
        return user;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        Collection<GrantedAuthority> collect = new ArrayList<>();
        collect.add( () ->{return user.getUserRole().getValue();});
        return collect;
    }

    @Override
    public String getPassword() {
        return user.getUserPassword();
    }

    @Override
    public String getUsername() {
        return user.getUserId();
    }

    @Override
    public boolean isAccountNonExpired() { //계정이 만료가 되었는지 확인
        return true; //false면 다 만료가 되었음
    }

    @Override
    public boolean isAccountNonLocked() { //계정 잠금이 되었는지 확인
        return true; //false면 잠금
    }

    @Override
    public boolean isCredentialsNonExpired() { //계정의 유효기간 확인
        return true; //false면 사용불가
    }

    @Override
    public boolean isEnabled() { //계정 사용가능 여부 확인
        return true;
    }
}
