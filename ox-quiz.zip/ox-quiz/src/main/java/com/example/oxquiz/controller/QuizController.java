package com.example.oxquiz.controller;

import com.example.oxquiz.dto.OorX;
import com.example.oxquiz.dto.QuizDto;
import com.example.oxquiz.entity.QuizEntity;
import com.example.oxquiz.service.QuizSerivce;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@Slf4j
public class QuizController {
    private final QuizSerivce quizSerivce;

    public QuizController(QuizSerivce quizSerivce) {
        this.quizSerivce = quizSerivce;
    }

    @GetMapping("/main")
    public String main(){
        return "/index";
    }//메인페이지 GetMapping

    @GetMapping("/submit")
    public String submitView(Model model,QuizDto quizDto){
        model.addAttribute("quizDto", quizDto);
        return "/submit";
    }// 질문 등록 페이지 GetMapping

    @PostMapping("/submit")
    public String submitService(@ModelAttribute("quizDto") QuizDto quizDto, Model model){
        quizSerivce.insertQuiz(quizDto);
        return "redirect:/quizList";
    } //질문 등록 페이지 GetMapping에서 가져온 내용을 quizDto로 가져와 DB에 넣음

    @GetMapping("/update/{updateId}")
    public String updateView(@PathVariable("updateId") Long id, Model model){
        QuizDto quizDto;
        quizDto = quizSerivce.showOne(id); // id값을 받아 id의 퀴즈를 찾아줌
        model.addAttribute("quizDto", quizDto); // update.html에 quizDto값을 전달
        return "/update";
    }//갱신페이지 GetMapping

    @PostMapping("/update")
    public String updateForm(@ModelAttribute("quizDto") QuizDto quizDto){
        quizSerivce.update(quizDto); //GetMapping 갱신페이지에서 받아온 quizDto를 Db에 업데이트
        return "redirect:/quizList";
    }// 갱신페이지 PostMapping

    @PostMapping("/delete/{deleteId}")
    public String deleteView(@PathVariable("deleteId") Long id){
        quizSerivce.delete(id); // id값을 받아 퀴즈를 삭제하는 메소드
        return "redirect:/quizList";
    }//삭제 PostMapping

    @GetMapping("/quizList")
    public String quizList(Model model){
        List<QuizDto> quizDto = quizSerivce.showAll(); //Repository에서 Entity로 가져와 Dto로 넘기는 showAll 메소드
        model.addAttribute("quizDto", quizDto);
        return "/quizList";
    }//퀴즈목록페이지 GetMapping
    @GetMapping("play")
    public String playView(Model model){
        String quiz = quizSerivce.getRandomQuiz();
        model.addAttribute("quiz" , quiz);
        return "play";
    }//게임페이지 GetMapping

    @PostMapping("play")
    public String play(@ModelAttribute("quizDto") QuizDto quizDto){
        return "play";
    }

    @ModelAttribute("OorX")
    private OorX[] oorXES(){
        return OorX.values();
    } // submit.html에 뿌리는 퀴즈 정답
}
