package com.example.oxquiz.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="quiz")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuizEntity {
    @Id //Primary key
    @GeneratedValue(strategy = GenerationType.AUTO) //자동증가
    private Long id;

    @Column(length = 255 , nullable = false)
    private String content;

    @Column(nullable = false)
    private boolean answer;

    @Column(length = 10 , nullable = false)
    private String name;
}
