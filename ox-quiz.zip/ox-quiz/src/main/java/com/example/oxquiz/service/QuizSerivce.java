package com.example.oxquiz.service;

import com.example.oxquiz.dto.QuizDto;
import com.example.oxquiz.entity.QuizEntity;
import com.example.oxquiz.repository.QuizRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class QuizSerivce {
    private final QuizRepository quizRepository;

    public QuizSerivce(QuizRepository quizRepository) {
        this.quizRepository = quizRepository;
    }

    public void insertQuiz(QuizDto quizDto){
        QuizEntity quizEntity = quizDto.fromQuizDto(quizDto); //Dto -> Entity
        quizRepository.save(quizEntity);
    } // 퀴즈 등록하는 메소드

    public List<QuizDto> showAll() {
        List<QuizDto> quizDtoList = new ArrayList<>();
        List<QuizEntity> quizEntityList = quizRepository.findAll();

        for (QuizEntity quizEntity : quizEntityList){
            quizDtoList.add(
                    QuizDto.fromQuizEntity(quizEntity)
            );
        }
        return quizDtoList;
    } // 퀴즈 전체 목록을 출력하는 메소드

    public void delete(Long id) {
        quizRepository.deleteById(id);
    } // id를 찾아 퀴즈 삭제

    public QuizDto showOne(Long id) {
        QuizEntity quizEntity = quizRepository.findById(id).orElse(null);
        QuizDto quizDto = QuizDto.fromQuizEntity(quizEntity);
        return quizDto;

    } //id를 찾아 퀴즈 정보 가져옴

    public void update(QuizDto quizDto) {
        QuizEntity quizEntity = QuizDto.fromQuizDto(quizDto);
        quizRepository.save(quizEntity);
    }


    public String getRandomQuiz(){
        return quizRepository.quizContent();
    }


}
