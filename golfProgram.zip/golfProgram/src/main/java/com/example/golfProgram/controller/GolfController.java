package com.example.golfProgram.controller;

import com.example.golfProgram.dto.ClassDto;
import com.example.golfProgram.dto.MemberDto;
import com.example.golfProgram.dto.TeacherDto;
import com.example.golfProgram.service.GolfService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
@Slf4j
public class GolfController {
    private final GolfService golfService;

    public GolfController(GolfService golfService) {
        this.golfService = golfService;
    }

    @GetMapping("/")
    public String main(){
        return "/articles/main";
    }
    @GetMapping("/teacherInfo")
    public String teacherInfo(Model model){
        List<TeacherDto> teacherDtoList = golfService.showTeacherInfoAll();
        model.addAttribute("teacherDtoList" , teacherDtoList);

        return "/articles/teacherInfo";
    } //강사정보조회

    @GetMapping("/regist")
    public String registrationView(Model model){
        List<TeacherDto> teacherDtoList = golfService.showTeacherInfoAll();
        List<MemberDto> memberDtoList = golfService.showMemberInfoAll();
        ClassDto classDto = new ClassDto();
        model.addAttribute("classDto" , classDto);
        model.addAttribute("teacherDtoList" , teacherDtoList);
        model.addAttribute("memberDtoList" , memberDtoList);
        return "/articles/registration";
    } //수강신청 GetMapping

    @PostMapping("/regist")
    public String registration(@ModelAttribute("classDto") ClassDto classDto){
        golfService.registration(classDto);
        return "/articles/memberInfo";
    } //수강신청 PostMappring

    @GetMapping("/memberInfo")
    public String memberInfo(Model model){
        List<ClassDto> classDtoList = golfService.showMemberClassInfoAll();
        model.addAttribute("classDtoList" , classDtoList);
        return "/articles/memberInfo";
    } //회원정보조회

    @GetMapping("/teacherProfit")
    public String teacherProfit(Model model){
        List<TeacherDto> teacherDtoList = golfService.showTeacherProfit();
        model.addAttribute("teacherDtoList" , teacherDtoList);
        return "/articles/teacherProfit";
    }
}
