package com.example.golfProgram.repository;

import com.example.golfProgram.entity.Class;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ClassRepository extends JpaRepository<Class,Long> {
    @Query(value = "SELECT COALESCE(SUM(tuition), 0) FROM class WHERE teacher_code = :teacherCode" , nativeQuery = true)
    int getTeacherProfit(@Param("teacherCode") String teacherCode); //선생코드로 수익 가져오는 sql
}
