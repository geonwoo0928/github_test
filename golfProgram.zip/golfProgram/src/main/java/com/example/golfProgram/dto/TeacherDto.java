package com.example.golfProgram.dto;

import com.example.golfProgram.entity.Teacher;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TeacherDto {
    private String teacherCode;
    private String teacherName;
    private String className;
    private int classPrice;
    private String teacherRegistDate;
    private int teacherProfit;

    public TeacherDto(String teacherCode, String teacherName, String className, int classPrice, String teacherRegistDate) {
        this.teacherCode = teacherCode;
        this.teacherName = teacherName;
        this.className = className;
        this.classPrice = classPrice;
        this.teacherRegistDate = teacherRegistDate;
    }//1

    public static TeacherDto entityToDto(Teacher teacher){
        return new TeacherDto(
                teacher.getTeacherCode(),
                teacher.getTeacherName(),
                teacher.getClassName(),
                teacher.getClassPrice(),
                teacher.getTeacherRegistDate()
        );
    }// 1   || entity -> dto

    public static TeacherDto entityToDtoTeacherProfit(Teacher teacher , int profit){
        return new TeacherDto(
                teacher.getTeacherCode(),
                teacher.getTeacherName(),
                teacher.getClassName(),
                teacher.getClassPrice(),
                teacher.getTeacherRegistDate(),
                profit
        );
    } // 총수익 추가
}
