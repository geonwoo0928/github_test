package com.example.golfProgram.dto;

import com.example.golfProgram.entity.Member;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MemberDto {
    private String memberId;
    private String memberName;
    private String phone;
    private String address;
    private String grade;


    public static MemberDto entityToDto(Member member){
        return new MemberDto(
                member.getMemberId(),
                member.getMemberName(),
                member.getPhone(),
                member.getAddress(),
                member.getGrade()
        );
    }
}
