package com.example.golfProgram.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Member {
    @Id
    @Column(length = 5,nullable = false)
    public String memberId;
    @Column(length = 15)
    public String memberName;
    @Column(length = 11)
    public String phone;
    @Column(length = 50)
    public String address;
    @Column(length = 6)
    public String grade;
}
