package com.example.golfProgram.service;

import com.example.golfProgram.dto.ClassDto;
import com.example.golfProgram.dto.MemberDto;
import com.example.golfProgram.dto.TeacherDto;
import com.example.golfProgram.entity.Class;
import com.example.golfProgram.entity.Member;
import com.example.golfProgram.entity.Teacher;
import com.example.golfProgram.repository.ClassRepository;
import com.example.golfProgram.repository.MemberRepository;
import com.example.golfProgram.repository.TeacherRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class GolfService {
    private final TeacherRepository teacherRepository;
    private final MemberRepository memberRepository;
    private final ClassRepository classRepository;

    public GolfService(TeacherRepository teacherRepository, MemberRepository memberRepository, ClassRepository classRepository) {
        this.teacherRepository = teacherRepository;
        this.memberRepository = memberRepository;
        this.classRepository = classRepository;
    }

    public List<TeacherDto> showTeacherInfoAll(){
        List<Teacher> teacherList = teacherRepository.findAll();
        List<TeacherDto> teacherDtoList = new ArrayList<>();

        for(Teacher teacher : teacherList){
            teacherDtoList.add(
                    TeacherDto.entityToDto(teacher));
        }
        return teacherDtoList;
    } // 강사조회

    public List<MemberDto> showMemberInfoAll(){
        List<Member> memberList = memberRepository.findAll();
        List<MemberDto> memberDtoList = new ArrayList<>();

        for(Member member : memberList){
            memberDtoList.add(
                    MemberDto.entityToDto(member)
            );
        }
        return memberDtoList;
    } //학생조회

    public void registration(ClassDto classDto) {
        Class aClass = ClassDto.dtoToEntity(classDto);
        classRepository.save(aClass);
    } //수강신청

    public List<ClassDto> showMemberClassInfoAll(){
        List<Class> classList = classRepository.findAll();
        List<ClassDto> classDtoList = new ArrayList<>();

        for(Class cls : classList){
            MemberDto memberDto = MemberDto.entityToDto(memberRepository.findById(cls.classNo).orElse(null));
            TeacherDto teacherDto = TeacherDto.entityToDto(teacherRepository.findById(cls.teacherCode).orElse(null));
            classDtoList.add(
                    ClassDto.entityToDto(cls,memberDto,teacherDto)
            );
        }
        return classDtoList;
    } //회원정보조회

    public List<TeacherDto> showTeacherProfit(){
        List<Teacher> teacherList = teacherRepository.findAll();
        List<TeacherDto> teacherDtoList = new ArrayList<>();

        for(Teacher teacher : teacherList){
            teacherDtoList.add(
                    TeacherDto.entityToDtoTeacherProfit(teacher , classRepository.getTeacherProfit(teacher.getTeacherCode())));
            //총 수익
        }
        return teacherDtoList;
    } //강사매출현황
}
