package com.example.golfProgram.dto;

import com.example.golfProgram.entity.Class;
import com.example.golfProgram.entity.Member;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClassDto {
    private Long classId;
    private String registMonth;
    private String classNo;
    private String classArea;
    private int tuition;
    private String teacherCode;
    private MemberDto memberDto;
    private TeacherDto teacherDto;



    public static ClassDto entityToDto(Class cls , MemberDto memberDto , TeacherDto teacherDto){
        return new ClassDto(
                cls.getClassId(),
                cls.getRegistMonth(),
                cls.getClassNo(),
                cls.getClassArea(),
                cls.getTuition(),
                cls.getTeacherCode(),
                memberDto,
                teacherDto
        );
    } // 회원정보조회 Entity To Dto

    public static Class dtoToEntity(ClassDto classDto){
        return new Class(
                classDto.getClassId(),
                classDto.getRegistMonth(),
                classDto.getClassNo(),
                classDto.getClassArea(),
                classDto.getTuition(),
                classDto.getTeacherCode()
                );
    }
}
