function updateMemberId() {
  var select = document.getElementById("memberSelect");
  var memberIdInput = document.getElementById("memberIdInput");
  var memberId = select.value;
  memberIdInput.value = memberId;
} // 회원명-회원번호 연동

function updateTuition() {
  var lectureSelect = document.getElementById("lectureSelect");
  var tuitionAmountElement = document.getElementById("tuitionAmount");
  var memberIdInput = document.getElementById("memberIdInput");
  var tuition = 0;
  var selectedLecture = lectureSelect.value;

     switch(selectedLecture) {
        case "100":
           tuition = 100000;
           break;
        case "200":
           tuition = 200000;
           break;
        case "300":
           tuition = 300000;
           break;
        case "400":
           tuition = 400000;
           break;
        default:
           tuition = 0;
     }

     if (parseInt(memberIdInput.value) >= 20000) {
         tuition /= 2;
     }// 회원번호 20000 이상 수강료 반값

     tuitionAmountElement.value = tuition;
}  //강의명-수강료 연동