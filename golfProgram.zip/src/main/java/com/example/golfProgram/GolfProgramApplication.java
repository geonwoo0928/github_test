package com.example.golfProgram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GolfProgramApplication {

	public static void main(String[] args) {
		SpringApplication.run(GolfProgramApplication.class, args);
	}

}
