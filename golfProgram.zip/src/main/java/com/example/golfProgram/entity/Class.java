package com.example.golfProgram.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Class {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long classId;

    @Column(length = 6)
    public String registMonth;

    @Column(length = 5)
    public String classNo;

    @Column(length = 15)
    public String classArea;

    public int tuition;

    @Column(length = 3)
    public String teacherCode;
}
