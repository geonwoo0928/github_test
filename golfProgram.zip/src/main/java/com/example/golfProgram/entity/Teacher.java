package com.example.golfProgram.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Teacher {
    @Id
    @Column(length = 3 , nullable = false)
    public String teacherCode;
    @Column(length = 15)
    public String teacherName;
    @Column(length = 20)
    public String className;
    public int classPrice;
    @Column(length = 8)
    public String teacherGegistDate;
}
