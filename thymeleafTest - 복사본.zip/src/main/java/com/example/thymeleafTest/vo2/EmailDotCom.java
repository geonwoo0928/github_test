package com.example.thymeleafTest.vo2;

import lombok.Getter;

@Getter
public enum EmailDotCom {
    naver("@naver.com"), daum("@daum.net"), google("@google.com");
    private final String description;

    EmailDotCom(String description) {
        this.description = description;
    }
}
