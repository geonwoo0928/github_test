package com.example.thymeleafTest.vo2;

import lombok.Getter;

@Getter
public enum gender {
    Male("남자"), Female("여자"), None("선택안함");
    private final String description;

    gender(String description) {
        this.description = description;
    }
}
