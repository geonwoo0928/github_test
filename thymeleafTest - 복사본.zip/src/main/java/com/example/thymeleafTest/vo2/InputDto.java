package com.example.thymeleafTest.vo2;

import lombok.Data;
@Data
public class InputDto {
    private String id;
    private String pw;
    private String identifiedPw;
    private String name;
    private String birth;
    private String gender;
    private String email;
    private String emailDotCom; //email 선택지 값
    private String phone;
    private boolean trueOrFalse; //전체 동의합니다.
    private boolean trueOrFalse2; //이용약관 동의
    private boolean trueOrFalse3; //개인정보 수집 이용 동의(필수)
    private boolean trueOrFalse4; //개인정보 수집 이용 동의(선택)

    public String getEmailCombined(){
        return this.email+"@"+this.emailDotCom+".com";
    }

    public boolean isPasswordMatch() {
        return pw.equals(identifiedPw);
    }
}
