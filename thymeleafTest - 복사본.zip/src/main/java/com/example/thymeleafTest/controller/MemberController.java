package com.example.thymeleafTest.controller;

import com.example.thymeleafTest.vo.Member;
import com.example.thymeleafTest.vo.Users;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class MemberController {
    @GetMapping("/member")
    public String member(Model model){
        createMember(model);
        return "/member/member";
    }
    @GetMapping("/block")
    public String block(Model model){
        createMember(model);
        return "block";
    }

    private void createMember(Model model) {
        List<Member> memberList = new ArrayList<>();        for(int i = 1; i < 16; i++){
            String formattedNumber = String.format("%02d", i);
            memberList.add(
                    new Member("김예진"+formattedNumber,
                            "우가연"+formattedNumber )
            );
        }
        LocalDateTime localDateTime = LocalDateTime.now();

        model.addAttribute("members",memberList);
        model.addAttribute("localDateTime",localDateTime);    }

}
