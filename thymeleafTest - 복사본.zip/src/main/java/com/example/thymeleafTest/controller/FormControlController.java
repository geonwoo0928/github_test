package com.example.thymeleafTest.controller;

import com.example.thymeleafTest.vo2.EmailDotCom;
import com.example.thymeleafTest.vo2.InputDto;
import com.example.thymeleafTest.vo2.gender;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@Slf4j
public class FormControlController {
    @GetMapping("signUp")
    public String getSignUp(Model model) {
        model.addAttribute("dto", new InputDto());
        return "/signUpView";
    }

    @ModelAttribute("emailDotCom")
    private EmailDotCom[] emailDotComs() {
        return EmailDotCom.values();
    }

    @ModelAttribute("gender")
    private gender[] genders() {
        return gender.values();
    }

    @PostMapping("signUp")
    public String postSignUp(@ModelAttribute("dto") InputDto dto, Model model) {
        if (dto.getGender().equals("Male")) {
            dto.setGender("남자");
        } else if (dto.getGender().equals("Female")) {
            dto.setGender("여자");
        } else {
            dto.setGender("선택안함");
        }
        if (!(dto.getPw().equals(dto.getIdentifiedPw()))) {
            model.addAttribute("passwordMismatch", true);
            return "/signUpView";
        }
        return "/signUpResultView";
    }

    @GetMapping("signUpView")
    public String getSignUpResult(Model model, InputDto dto) {
        return "/signUpResultView";
    }
}
