package com.example.thymeleafTest.vo;

import java.util.ArrayList;
import java.util.List;

public class Link {
    int postNum;
    int commentNum;
    String name;
    int height;
    int weight;

    public Link(int postNum, int commentNum, String name, int height, int weight) {
        this.postNum = postNum;
        this.commentNum = commentNum;
        this.name = name;
        this.height = height;
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "link{" +
                "postNum=" + postNum +
                ", commentNum=" + commentNum +
                ", name='" + name + '\'' +
                ", height=" + height +
                ", weight=" + weight +
                '}';
    }

    public int getPostNum() {
        return postNum;
    }

    public void setPostNum(int postNum) {
        this.postNum = postNum;
    }

    public int getCommentNum() {
        return commentNum;
    }

    public void setCommentNum(int commentNum) {
        this.commentNum = commentNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
}
