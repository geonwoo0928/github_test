package com.example.thymeleafTest.vo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
public enum Language { //선택지가 정해져있을때 ex) 회원/비회원 , 남자/여자
    JAVA("자바"), C("C언어"), CPP("C++"), PYTHON("파이썬");

    private final String description;

    Language(String description) {
        this.description = description;
    }
}
